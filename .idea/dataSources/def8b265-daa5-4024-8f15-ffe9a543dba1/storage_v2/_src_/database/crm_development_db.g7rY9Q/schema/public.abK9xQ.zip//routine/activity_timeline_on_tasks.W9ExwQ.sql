create function activity_timeline_on_tasks() returns trigger
    language plpgsql
as
$$
    DECLARE
        type_label VARCHAR(50);
        attributes_new JSONB;
        assignee_details JSONB;
        created_by_details JSONB;
        updated_by_details JSONB;
        tags_det JSONB;
    BEGIN
        -- Determine the type of operation (INSERT, UPDATE, DELETE)
        IF TG_OP = 'UPDATE' THEN
            -- Check if the task is being deleted
            IF NEW.deleted_at IS NOT NULL THEN
                type_label := 'DELETED';
                IF TG_ARGV[0] IN ('TASK') THEN
                    UPDATE providers_activity_timelines
                    SET deleted_at = NOW()
                    WHERE entity = OLD.id
                    AND entity_type = TG_ARGV[0]
                    AND type IN ('ADDED', 'UPDATED');
                END IF;
            ELSE
                type_label := 'UPDATED';
            END IF;
            -- Fetch updated attributes
            SELECT jsonb_object_agg(key, value)
            INTO attributes_new
            FROM jsonb_each(to_jsonb(NEW));
            -- Fetch updated_by details
            SELECT jsonb_build_object(
                'id', u.id,
                'name', u.name,
                'email', u.email
            )
            INTO updated_by_details
            FROM authenticator_users u
            WHERE u.id = NEW.updated_by_id;
            -- Fetch tags related to the task
            SELECT jsonb_agg(jsonb_build_object(
                'id', t.id,
                'name', t.name,
                'color', t.color
            ))
            INTO tags_det
            FROM providers_tags t
            INNER JOIN providers_task_tags tt ON t.id = tt.tag_id
            WHERE tt.task_id = NEW.id;
            -- Add updated_by and tags to attributes_new
            attributes_new := attributes_new || jsonb_build_object('updated_by', updated_by_details, 'tags', tags_det);
            IF NEW.title <> OLD.title THEN
                attributes_new := attributes_new || jsonb_build_object(
                    'old_title', OLD.title,
                    'new_title', NEW.title
                );
            END IF;
        ELSE
            -- For INSERT operation
            type_label := 'ADDED';
            -- Fetch assignee details
            SELECT jsonb_build_object(
                'id', a.id,
                'name', a.name,
                'email', a.email,
                'phone_number', a.phone_number
            )
            INTO assignee_details
            FROM authenticator_users a
            WHERE a.id = NEW.assignee_id;
            -- Fetch created_by details
            SELECT jsonb_build_object(
                'id', u.id,
                'name', u.name,
                'email', u.email
            )
            INTO created_by_details
            FROM authenticator_users u
            WHERE u.id = NEW.created_by_id;
            -- Fetch updated_by details
            SELECT jsonb_build_object(
                'id', u.id,
                'name', u.name,
                'email', u.email
            )
            INTO updated_by_details
            FROM authenticator_users u
            WHERE u.id = NEW.updated_by_id;
            -- Fetch tags related to the task
            SELECT jsonb_agg(jsonb_build_object(
                'id', t.id,
                'name', t.name,
                'color', t.color
            ))
            INTO tags_det
            FROM providers_tags t
            INNER JOIN providers_task_tags tt ON t.id = tt.tag_id
            WHERE tt.task_id = NEW.id;
            -- Combine assignee, created_by, updated_by, and tags into attributes_new
            attributes_new := to_jsonb(NEW) || jsonb_build_object(
                'assignee', assignee_details,
                'created_by', created_by_details,
                'updated_by', updated_by_details,
                'tags', tags_det
            );
        END IF;
        -- Insert into providers_activity_timelines
        IF NEW.contact_id IS NOT NULL THEN
            INSERT INTO providers_activity_timelines 
                (contact_id, activity_by_id, entity, entity_type, type, attributes, created_at, updated_at)
            VALUES
                (NEW.contact_id, NEW.updated_by_id, NEW.id, TG_ARGV[0], type_label::public.enum_providers_activity_timelines_type, attributes_new, NOW(), NOW());
        END IF;
        RETURN NEW;
    END;
    $$;

alter function activity_timeline_on_tasks() owner to postgres;

