create function conference_interaction_analytic(workspaceid integer, fromdate date, todate date)
    returns TABLE(averageanswertime numeric)
    language sql
as
$$
        WITH temp_avg_ans_tbl AS (
          SELECT
            message_conversation_id,
            ROW_NUMBER() OVER (PARTITION BY message_conversation_id) AS rn,
            start_date - LEAD(start_date) OVER (PARTITION BY pcsc.message_conversation_id ORDER BY pcsc.created_at DESC) as time_diff
          FROM provider_conference_status_callbacks pcsc
          LEFT JOIN message_conversations mc ON mc.id = pcsc.message_conversation_id
          WHERE pcsc.workspace_id = workspaceId
          AND mc.agent_id IS NOT NULL
          AND mc.direction  = 'incoming'
          AND (pcsc.call_type IS NULL OR pcsc.call_type = 'client')
          AND pcsc.created_at BETWEEN fromDate AND toDate
        )
        SELECT COALESCE(EXTRACT(EPOCH FROM AVG(time_diff)), 0) as averageAnswerTime
        FROM temp_avg_ans_tbl
        WHERE rn = 1;
      $$;

alter function conference_interaction_analytic(integer, date, date) owner to postgres;

