create function activity_timeline_on_contacts() returns trigger
    language plpgsql
as
$$
    DECLARE
      type varchar(50);
      attributes jsonb;
    BEGIN
   IF TG_OP = 'UPDATE' AND NEW.deleted_at IS NOT NULL THEN
        type := 'DELETED';
        attributes := '{}';
    ELSIF TG_OP = 'UPDATE' THEN
        type := 'UPDATED';
        SELECT COALESCE(jsonb_object_agg(columname, postvalue), '{}'::jsonb) INTO attributes
        FROM (
          SELECT pre.key AS columname, pre.value AS prevalue, post.value AS postvalue
          FROM jsonb_each(to_jsonb(OLD)) AS pre
          CROSS JOIN jsonb_each(to_jsonb(NEW)) AS post
          WHERE pre.key = post.key AND pre.value IS DISTINCT FROM post.value
        ) AS updated_values;
    ELSE 
        type := 'ADDED';
        attributes := to_jsonb(NEW);
    END IF;
        INSERT INTO providers_activity_timelines 
          (contact_id, activity_by_id, entity, entity_type, type, attributes, created_at, updated_at)
          VALUES
          (NEW.id, NEW.updated_by_id, NEW.id, TG_ARGV[0], type::public.enum_providers_activity_timelines_type, attributes, NOW(), NOW());
        RETURN NEW;
    END;
    $$;

alter function activity_timeline_on_contacts() owner to postgres;

