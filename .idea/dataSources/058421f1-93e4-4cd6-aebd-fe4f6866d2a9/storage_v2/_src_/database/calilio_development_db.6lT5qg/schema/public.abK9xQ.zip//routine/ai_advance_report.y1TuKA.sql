create function ai_advance_report(workspaceid integer, from_date date, to_date date, sentiment_type character varying, reason_type character varying, conclusion_type character varying, userworkspaceid integer, limit_count integer, offset_count integer, sorting_column character varying, sort_asc boolean)
    returns TABLE("userName" character varying, "callDirection" character varying, "createdAt" date, "agentPhoneNumber" character varying, "transcriptionId" integer, "callRecordingId" integer, "callRecordingUrl" character varying)
    language plpgsql
as
$$
                DECLARE
                base_query TEXT;
                final_query TEXT;
                        mid_query TEXT;
    
            BEGIN
                base_query := '
                WITH
                transcription_phrases AS (
                    SELECT DISTINCT transcription_information_id
                    FROM transliterate_transcription_key_phrases
                    WHERE 
                    ($1 = ''empty'' OR (intent = $1 AND type = ''reason''))
                    AND ($2 = ''empty'' OR (intent = $2 AND type = ''conclusion''))

                ),
                accepted_workspaces AS (
                    SELECT uw.ID user_workspace_id, uw.user_id, uw.workspace_id 
                    FROM user_workspaces uw 
                    WHERE uw.status = ''accepted'' 
                    AND ($3 = 0 OR uw.workspace_id = $3)
                ),
                message_data AS (
                    SELECT 
                        mc.ID,
                        mc.agent_id,
                        mc.client_id,
                        mc.direction,
                        mc.created_at::DATE,
                        mc.workspace_id,
                        mc.conversation_status,
                        mc.conversation_type 
                    FROM message_conversations mc 
                    WHERE
                        mc.conversation_type = ''conference'' 
                        AND mc.conversation_status = ''completed'' 
                        AND mc.created_at::date BETWEEN $4 AND $5 
                        AND ($3 = 0 OR mc.workspace_id = $3)
                ),
                transcription_info AS (
                    SELECT 
                        tti.ID AS transcription_id,
                        pcr.message_conversation_id,
                        tti.sentiment,
                        pcr.ID AS call_recording_id, pcr.url as call_recording_url
                    FROM transliterate_transcription_information tti
                    INNER JOIN provider_call_recordings pcr ON tti.provider_call_recordings_id = pcr.ID 
                    WHERE  ($3 = 0 OR tti.workspace_id = $3) AND tti.created_at::date BETWEEN $4 AND $5 AND ($6 = ''empty'' OR tti.sentiment::VARCHAR = $6) AND  tti.job_status = ''COMPLETED'' and case when ($1 = ''empty'' and $2 = ''empty'') then true else tti.id in (select transcription_information_id from  transcription_phrases) end
                )
                SELECT asa.* FROM (SELECT distinct
                    uu.NAME,
                    mc.direction::varchar,
                    mc.created_at,
                    cc.phone_number AS agent_phone_number,
                    tti.transcription_id,
                    tti.call_recording_id, tti.call_recording_url
                FROM users uu
                INNER JOIN accepted_workspaces uw ON uu.ID = uw.user_id
                INNER JOIN message_data mc ON mc.agent_id = uw.user_workspace_id
                INNER JOIN contacts cc ON cc.ID = mc.client_id
                INNER JOIN transcription_info tti ON tti.message_conversation_id = mc.ID 
                WHERE 
                    tti.transcription_id IN (SELECT transcription_id FROM transcription_info)
                    AND ($7 = 0 OR uw.user_workspace_id = $7)';
            mid_query := ')asa union all 
                        select  ''aaaxyz'' AS nm,
                        NULL AS direction,
                        NULL AS created_at,
                        NULL AS agent_phone_number,
                        count(distinct asa.call_recording_id)::int4 AS transcription_id,
                        NULL AS call_recording_id, NULL as call_recording_url  from (SELECT distinct
                    uu.NAME,
                    mc.direction::varchar,
                    mc.created_at,
                    cc.phone_number AS agent_phone_number,
                    tti.transcription_id,
                    tti.call_recording_id 
                FROM users uu
                INNER JOIN accepted_workspaces uw ON uu.ID = uw.user_id
                INNER JOIN message_data mc ON mc.agent_id = uw.user_workspace_id
                INNER JOIN contacts cc ON cc.ID = mc.client_id
                INNER JOIN transcription_info tti ON tti.message_conversation_id = mc.ID 
                WHERE 
                    tti.transcription_id IN (SELECT transcription_id FROM transcription_info)
                    AND ($7 = 0 OR uw.user_workspace_id = $7))asa GROUP BY nm
                ';
            
                -- Add the dynamic ORDER BY clause
                final_query := base_query || ' ORDER BY ' || quote_ident(sorting_column) || 
                            CASE WHEN sort_asc THEN ' ASC ' ELSE ' DESC ' END ||
                            ' LIMIT ' || limit_count || ' OFFSET ' || offset_count || mid_query;
            
                RETURN QUERY EXECUTE final_query
                USING reason_type, conclusion_type, workspaceid, from_date, to_date, sentiment_type, userworkspaceid;
            END;
            $$;

alter function ai_advance_report(integer, date, date, varchar, varchar, varchar, integer, integer, integer, varchar, boolean) owner to postgres;

