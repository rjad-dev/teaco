create function aidashboard_count(workspaceid integer, from_date date, to_date date)
    returns TABLE(sentiment character varying, "totalCount" integer, percentage real)
    language sql
as
$$
      -- WITH sentiment_details AS (
      --     SELECT 
      --         (jsonb_data->>'Sentiment') AS sentiment, 
      --         workspace_id  
      --     FROM 
      --         transliterate_transcription_information AS tti, 
      --         jsonb_array_elements(call_summary_with_speaker) AS jsonb_data 
      --     WHERE 
      --         tti.sentiment IS NOT NULL 
      --         AND tti.created_at::date BETWEEN from_date AND to_date
      --         AND tti.workspace_id = workspaceid and tti.job_status = 'COMPLETED'
      -- )
      -- SELECT 
      --     sentiment, 
      --     COUNT(sentiment) AS totalCount, 
      --     ROUND((COUNT(sentiment)::float * 100 / (SELECT COUNT(sentiment) FROM sentiment_details))::numeric, 2) AS percentage
      -- FROM 
      --     sentiment_details 
      -- GROUP BY 
      --     sentiment;
      
      
          WITH sentiment_details AS (
        SELECT 
              tti.sentiment, 
              tti.workspace_id  
        FROM 
              transliterate_transcription_information AS tti
        WHERE 
            tti.sentiment IS NOT NULL 
              AND tti.created_at::date BETWEEN from_date and to_date
              AND tti.workspace_id = workspaceid and  tti.job_status = 'COMPLETED'
    )
    SELECT 
        sentiment, 
        COUNT(sentiment) AS totalCount, 
        ROUND((COUNT(sentiment)::float * 100 / (SELECT COUNT(sentiment) FROM sentiment_details))::numeric, 2) AS percentage
    FROM 
        sentiment_details 
      GROUP BY  sentiment;
            $$;

alter function aidashboard_count(integer, date, date) owner to postgres;

