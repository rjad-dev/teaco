create function aidashboard_intent(workspaceid integer, from_date date, to_date date, intent_type character varying, limit_count integer, offset_count integer, sorting_column character varying, sort_asc boolean)
    returns TABLE(intent character varying, "currentCount" integer, "previousCount" integer, "currentSentiment" character varying, "previousSentiment" character varying)
    language plpgsql
as
$$
      DECLARE
            base_query TEXT;
            final_query TEXT;
            mid_query TEXT;
        BEGIN
            base_query := '
                      WITH current_call_details AS
            (
                SELECT
                    ttkp.intent,
                    COUNT(distinct tti.provider_call_recordings_id) AS current_count,
                    tti.sentiment AS current_sentiment
                FROM
                    transliterate_transcription_key_phrases ttkp
                    INNER JOIN transliterate_transcription_information tti ON (tti.ID = ttkp.transcription_information_id 
                    AND tti.created_at::date BETWEEN $2 AND $3 AND tti.workspace_id = $1)
                WHERE ttkp."type"::varchar = $4
                GROUP BY ttkp.intent, tti.sentiment
            ),
            previous_call_details AS
            (
                SELECT
                    ttkp.intent,
                    COUNT(tti.provider_call_recordings_id) AS previous_count,
                    tti.sentiment AS previous_sentiment
                FROM
                    transliterate_transcription_key_phrases ttkp
                    INNER JOIN transliterate_transcription_information tti ON (tti.ID = ttkp.transcription_information_id 
                    AND tti.created_at::date BETWEEN ($2 - ($3 - $2)) AND $2 AND tti.workspace_id = $1)
                WHERE ttkp."type"::varchar = $4
                GROUP BY ttkp.intent, tti.sentiment
            )
            SELECT asa.* FROM (SELECT
                COALESCE(ccd.intent, pcd.intent) as intent,
                COALESCE(ccd.current_count, 0)::int4 AS current_count,
                COALESCE(pcd.previous_count, 0)::int4 AS previous_count,
                ccd.current_sentiment::varchar,
                pcd.previous_sentiment::varchar
            FROM current_call_details ccd 
            FULL OUTER JOIN previous_call_details pcd ON ccd.intent = pcd.intent
  ';
      mid_query := ')asa union all 
            SELECT
               ''aaaxyz'' it,
                count(*)::int4 AS current_count, 
                NULL,
                NULL,
                NULL
            FROM current_call_details ccd 
            FULL OUTER JOIN previous_call_details pcd ON ccd.intent = pcd.intent GROUP BY it';
            
  
  -- Add the dynamic ORDER BY clause
            final_query := base_query || ' ORDER BY ' || quote_ident(sorting_column) || 
                          CASE WHEN sort_asc THEN ' ASC ' ELSE ' DESC ' END ||
                          ' LIMIT ' || limit_count || ' OFFSET ' || offset_count || mid_query;
        
            RETURN QUERY EXECUTE final_query
            USING workspaceid, from_date, to_date, intent_type;
        END;
        $$;

alter function aidashboard_intent(integer, date, date, varchar, integer, integer, varchar, boolean) owner to postgres;

