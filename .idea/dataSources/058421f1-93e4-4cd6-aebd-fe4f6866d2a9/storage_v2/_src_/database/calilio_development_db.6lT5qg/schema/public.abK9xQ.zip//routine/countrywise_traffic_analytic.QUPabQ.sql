create function countrywise_traffic_analytic(workspaceid integer, fromdate date, todate date)
    returns TABLE(label character varying, received integer, sent integer)
    language sql
as
$$
        SELECT 
          ac.name AS label,
          COUNT(ac.name) FILTER(WHERE mc.direction = 'incoming') as received,
          COUNT(ac.name) FILTER(WHERE mc.direction = 'outgoing') as sent
        FROM message_conversations AS mc 
        LEFT JOIN contacts AS c ON mc.client_id = c.id 
        INNER JOIN authenticator_countries AS ac ON c.country_id = ac.id
        WHERE mc.workspace_id = workspaceId 
        AND mc.created_at BETWEEN fromDate AND toDate
        GROUP BY ac.name;
      $$;

alter function countrywise_traffic_analytic(integer, date, date) owner to postgres;

