create function aidashboard_daywise_sentiment(workspaceid integer, from_date date, to_date date)
    returns TABLE("createdAt" date, "positiveSentimentCount" integer, "negativeSentimentCount" integer)
    language sql
as
$$
          
              WITH date_series AS (
          SELECT generate_series(from_date, to_date, '1 day'::interval)::date AS created_at
      ),
      jsonb_details AS (
          SELECT 
              (jsonb_data->>'Sentiment') AS sentiment, 
              (jsonb_data->>'ParticipantRole') AS participant_role, 
              created_at::date
          FROM 
              transliterate_transcription_information, 
              jsonb_array_elements(call_summary_with_speaker) AS jsonb_data 
          WHERE 
              created_at::date BETWEEN from_date AND to_date 
              AND workspace_id = workspaceid
      )
      SELECT 
          ds.created_at, 
          COALESCE(SUM(CASE WHEN jd.sentiment = 'POSITIVE' THEN 1 ELSE 0 END), 0) AS positive_sentiment_count, 
          COALESCE(SUM(CASE WHEN jd.sentiment = 'NEGATIVE' THEN 1 ELSE 0 END), 0) AS negative_sentiment_count
      FROM 
          date_series ds
      LEFT JOIN 
          jsonb_details jd 
      ON 
          ds.created_at = jd.created_at 
          AND jd.participant_role = 'CUSTOMER' 
          AND jd.sentiment IN ('POSITIVE', 'NEGATIVE')
      GROUP BY 
          ds.created_at
      ORDER BY 
          ds.created_at ASC;
      
              
              $$;

alter function aidashboard_daywise_sentiment(integer, date, date) owner to postgres;

