create function activity_timeline_on_deal_attachments() returns trigger
    language plpgsql
as
$$
      DECLARE 
        type VARCHAR(50);
        attributes JSONB;
        created_by_details JSONB;
        updated_by_details JSONB;
        attachment_details JSONB;
      BEGIN
        IF TG_OP = 'UPDATE' THEN
          IF NEW.deleted_at IS NOT NULL THEN
            type := 'DELETED';

            IF TG_ARGV[0] = 'ATTACHMENT' THEN
            UPDATE providers_activity_timelines
            SET deleted_at = NOW()
            WHERE entity = NEW.id AND entity_type = 'ATTACHMENT' AND providers_activity_timelines.type = 'ADDED';
          END IF;
          
          ELSE  
            type:= 'UPDATED';
          END IF;
          SELECT jsonb_build_object(
            'id', u.id,
            'name', u.name,
            'email', u.email
          ) INTO updated_by_details
          FROM authenticator_users u
          WHERE u.id = NEW.updated_by_id;

          SELECT jsonb_build_object(
            'id', m.id,
            'originalname', m.originalname,
            'mimetype', m.mimetype,
            'url', m.url,
            'filesize', m.size
          ) INTO attachment_details
          FROM upload_medias m
          WHERE m.id = NEW.attachment_id;

          SELECT jsonb_build_object(
            'attachment_id', NEW.attachment_id,
            'deal_id', NEW.deal_id,
            'created_by_id', NEW.created_by_id,
            'updated_by_id', NEW.updated_by_id
          ) INTO attributes;

          attributes := attributes || jsonb_build_object(
            'attachment', attachment_details,
            'created_by', created_by_details,
            'updated_by', updated_by_details
          );
        ELSE
          type := 'ADDED';
          SELECT jsonb_build_object(
            'id', u.id,
            'name', u.name,
            'email', u.email
          ) INTO created_by_details
          FROM authenticator_users u
          WHERE u.id = new.created_by_id;

          SELECT jsonb_build_object(
            'id', u.id,
            'name', u.name,
            'email', u.email
          ) INTO updated_by_details
          FROM authenticator_users u
          WHERE u.id = new.updated_by_id;

          SELECT jsonb_build_object(
            'id', m.id,
            'originalname', m.originalname,
            'mimetype', m.mimetype,
            'url', m.url,
            'filesize', m.size
          ) INTO attachment_details
          FROM upload_medias m
          WHERE m.id = new.attachment_id;

          SELECT jsonb_build_object(
            'attachment_id', NEW.attachment_id,
            'deal_id', NEW.deal_id,
            'created_by_id', NEW.created_by_id,
            'updated_by_id', NEW.updated_by_id
          ) INTO attributes;

          attributes := attributes || jsonb_build_object(
            'attachment', attachment_details,
            'created_by', created_by_details,
            'updated_by', updated_by_details
          );
        END IF;

        INSERT INTO providers_activity_timelines (
          deal_id,
          activity_by_id,
          entity,
          entity_type,
          type,
          attributes,
          created_at,
          updated_at
        ) VALUES (
          NEW.deal_id,
          CASE WHEN TG_OP = 'INSERT' THEN NEW.created_by_id ELSE NEW.updated_by_id END,
          NEW.id,
          TG_ARGV[0],
          type::public.enum_providers_activity_timelines_type,
          attributes,
          NOW(),
          NOW()
        );

        RETURN NEW;
      END;
      $$;

alter function activity_timeline_on_deal_attachments() owner to postgres;

