create function activity_timeline_on_contact_notes() returns trigger
    language plpgsql
as
$$
    DECLARE
        type_value varchar(50);
        attributes_new jsonb;
        created_by_details jsonb;
        updated_by_details jsonb;
    BEGIN
        IF NEW.entity_type = 'Contact' THEN
            IF TG_OP = 'DELETE' THEN
                type_value := 'DELETED';
                attributes_new := '{}';
            ELSIF TG_OP = 'UPDATE' AND NEW.deleted_at IS NOT NULL THEN
                type_value := 'DELETED';
                attributes_new := to_jsonb(NEW);
                IF TG_ARGV[0] IN ('NOTE') THEN
                    UPDATE providers_activity_timelines
                    SET deleted_at = NOW()
                    WHERE entity = OLD.id
                    AND entity_type = TG_ARGV[0]
                    AND type IN ('ADDED', 'UPDATED');
                END IF;
                SELECT jsonb_build_object(
                    'id', u.id,
                    'name', u.name,
                    'email', u.email
                ) INTO created_by_details
                FROM authenticator_users u
                WHERE u.id = NEW.created_by_id;
                
                SELECT jsonb_build_object(
                    'id', u.id,
                    'name', u.name,
                    'email', u.email
                ) INTO updated_by_details
                FROM authenticator_users u
                WHERE u.id = NEW.updated_by_id;

                attributes_new := attributes_new || jsonb_build_object(
                    'created_by', created_by_details,
                    'updated_by', updated_by_details
                );
            ELSIF TG_OP = 'UPDATE' THEN
                type_value := 'UPDATED';
                SELECT jsonb_object_agg(key, value) INTO attributes_new
                FROM (
                    SELECT key, value
                    FROM jsonb_each(to_jsonb(NEW))
                ) AS new_values;
    
                SELECT jsonb_build_object(
                    'id', u.id,
                    'name', u.name,
                    'email', u.email
                ) INTO updated_by_details
                FROM authenticator_users u
                WHERE u.id = NEW.updated_by_id;
    
                attributes_new := attributes_new || jsonb_build_object('updated_by', updated_by_details);
            ELSE
                type_value := 'ADDED';
                attributes_new := to_jsonb(NEW);
    
                SELECT jsonb_build_object(
                    'id', u.id,
                    'name', u.name,
                    'email', u.email
                ) INTO created_by_details
                FROM authenticator_users u
                WHERE u.id = NEW.created_by_id;
    
                SELECT jsonb_build_object(
                    'id', u.id,
                    'name', u.name,
                    'email', u.email
                ) INTO updated_by_details
                FROM authenticator_users u
                WHERE u.id = NEW.updated_by_id;
    
                attributes_new := attributes_new || jsonb_build_object(
                    'created_by', created_by_details,
                    'updated_by', updated_by_details
                );
            END IF;
    
            INSERT INTO providers_activity_timelines (
                contact_id,
                activity_by_id,
                entity,
                entity_type,
                type,
                attributes,
                created_at,
                updated_at
            ) VALUES (
                NEW.entity_id,
                CASE WHEN TG_OP = 'INSERT' THEN NEW.created_by_id ELSE NEW.updated_by_id END,
                NEW.id,
                TG_ARGV[0],
                type_value::public.enum_providers_activity_timelines_type,
                attributes_new,
                NOW(),
                NOW()
            );
    
            RETURN NEW;
        END IF;
        RETURN NEW;
    END;
    $$;

alter function activity_timeline_on_contact_notes() owner to postgres;

