create function message_analytics(workspaceid integer, datetimetype character varying, fromdate date, todate date)
    returns TABLE(label character varying, received integer, sent integer)
    language sql
as
$$
        SELECT
          CASE 
            WHEN dateTimeType = 'hour' THEN extract(hour FROM AGE(now(),created_at))::VARCHAR
            WHEN dateTimeType = 'weekDays' THEN to_char(created_at, 'Dy')
            ELSE date_trunc(dateTimeType, created_at)::VARCHAR
          END as label,
          COUNT('label') FILTER(WHERE direction = 'incoming':: enum_message_conversations_direction) as received,
          COUNT('label') FILTER(WHERE direction = 'outgoing':: enum_message_conversations_direction) as sent
        FROM message_conversations
        WHERE workspace_id = workspaceId AND created_at BETWEEN fromDate AND toDate
        GROUP BY label
        ORDER BY label;
      $$;

alter function message_analytics(integer, varchar, date, date) owner to postgres;

