create function average_call_rating(workspaceid integer)
    returns TABLE(averagerating integer)
    language sql
as
$$
      SELECT AVG(rating) as averageRating
      FROM provider_reviews
      WHERE workspace_id = workspaceId;
    $$;

alter function average_call_rating(integer) owner to postgres;

