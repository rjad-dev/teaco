create function workspace_member_analytic(workspaceid integer, fromdate date, todate date, fetchlimit integer, cursor bigint, cursorsort text)
    returns TABLE(id bigint, member jsonb, "inboundConference" bigint, "outboundConference" bigint, "missedConference" bigint, duration interval, "lastOnlineSince" timestamp without time zone)
    language sql
as
$$
      SELECT
        uw.id AS id,
        jsonb_build_object(
          'id', uw.user_id,
          'name', u.name,
          'email', u.email,
          'phoneNumber', u.phone_number,
          'profilePicture', jsonb_build_object(
            'id', um.id,
            'originalname', um.originalname,
            'mimetype', um.mimetype,
            'size', um.size,
            'key', um.key,
            'url', um.url
          )
        ) AS member,
        COUNT(*) FILTER(WHERE mc.direction = 'incoming' AND mc.conversation_status = 'completed' AND uw.id IN (mc.agent_id) AND mc.channel_id = cuw.channel_id AND mc.created_at BETWEEN fromDate AND toDate) AS inboundConference,
        COUNT(*) FILTER(WHERE mc.direction = 'outgoing' AND uw.id IN (mc.agent_id) AND mc.channel_id = cuw.channel_id AND mc.created_at BETWEEN fromDate AND toDate) AS outboundConference,
        COUNT(*) FILTER(WHERE mc.direction = 'incoming' AND (uw.id <> mc.agent_id OR mc.agent_id IS NULL) AND mc.channel_id = cuw.channel_id AND mc.created_at BETWEEN fromDate AND toDate) AS missedConference,
        SUM(CASE
          WHEN mc.direction = 'outgoing' AND mc.created_at BETWEEN fromDate AND toDate AND uw.id IN (mc.agent_id) AND mc.channel_id = cuw.channel_id THEN pcs.end_date - pcs.start_date
          WHEN mc.direction = 'incoming' AND mc.created_at BETWEEN fromDate AND toDate AND uw.id IN (mc.agent_id) AND mc.channel_id = cuw.channel_id THEN pcs.end_date - pcs.start_date
          ELSE INTERVAL '0' 
        END) AS duration,
        uw.last_login_at as lastOnlineSince
      FROM (
        SELECT DISTINCT ON (uw.user_id) uw.id, uw.user_id, uw.workspace_id, uw.last_login_at
        FROM user_workspaces uw
        WHERE uw.workspace_id = workspaceId AND uw.status = 'accepted' AND uw.deleted_at IS NULL
        AND (
          (cursorSort = 'DESC' AND uw.id < cursor) OR
          (cursorSort = 'ASC' AND uw.id > cursor)
        )
      ) AS uw
      LEFT JOIN users u ON uw.user_id = u.id
      LEFT JOIN message_conversations mc ON uw.workspace_id = mc.workspace_id
      LEFT JOIN provider_conference_status_callbacks pcs ON mc.id = pcs.message_conversation_id
      LEFT JOIN upload_medias um ON u.profile_id = um.id
      LEFT JOIN channel_user_workspaces cuw ON uw.id = cuw.user_workspace_id
      WHERE mc.conversation_type = 'conference'
        AND pcs.call_type = 'client' 
        AND pcs.workspace_id = workspaceId
        AND cuw.deleted_at IS NULL
      GROUP BY uw.id, uw.user_id, u.name, u.email, u.phone_number, um.id, uw.last_login_at
      ORDER BY
        CASE WHEN cursorSort = 'DESC' THEN uw.id END DESC,
        CASE WHEN cursorSort = 'ASC' THEN uw.id END ASC
      LIMIT fetchLimit
      $$;

alter function workspace_member_analytic(integer, date, date, integer, bigint, text) owner to postgres;

