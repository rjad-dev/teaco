create function aidashboard_summary_conclusion_negative_sentiments(workspaceid integer, from_date date, to_date date)
    returns TABLE("reasonForCall" character varying, conclusion character varying, "proposedSolution" character varying, "agentName" character varying, "customerPhoneNumber" character varying, "transcriptionId" integer, "callRecordingId" integer, percentage real, "callRecordingUrl" character varying)
    language sql
as
$$

            WITH jsonb_details AS (
              SELECT  DISTINCT  id as transcription_id, provider_call_recordings_id as call_recording_id,
                  (jsonb_data->>'Sentiment') AS sentiment, 
                  (jsonb_data->>'ParticipantRole') AS participant_role, 
                  (jsonb_data->>'Content') AS cont, 
                  reason_for_call, alternative, conclusion,  workspace_id, agent_id, client_id
              FROM 
                  transliterate_transcription_information, 
                  jsonb_array_elements(call_summary_with_speaker) AS jsonb_data 
              WHERE 
          created_at::date BETWEEN from_date and to_date and workspace_id = workspaceid and job_status = 'COMPLETED' and (call_summary is not null and call_summary<>'' and trim(call_summary)<>'')
            ),
          total_count as (
              select workspace_id, count(sentiment) ct, sentiment, participant_role, reason_for_call, conclusion, alternative, transcription_id, call_recording_id  from jsonb_details where participant_role = 'CUSTOMER' and sentiment = 'NEGATIVE'
              GROUP BY workspace_id,  sentiment,participant_role, reason_for_call, conclusion, alternative, transcription_id, call_recording_id 
              ),
              total_sum AS (
                  select transcription_id, count(sentiment) ct from jsonb_details where participant_role = 'CUSTOMER' GROUP BY transcription_id
                ),
              users_information as
              (
              select uu.NAME, cc.phone_number AS customerPhoneNumber, jd.workspace_id, jd.transcription_id, jd.call_recording_id,ROW_NUMBER() OVER(
              partition by jd.workspace_id ,uu.NAME, cc.phone_number
              ORDER BY  jd.workspace_id , uu.NAME, cc.phone_number
                )from jsonb_details jd  
              inner join user_workspaces uw on jd.agent_id = uw.id and uw.status = 'accepted' and uw.workspace_id = workspaceid
              inner join contacts cc on jd.client_id = cc.id
              inner join users uu on uw.user_id = uu.id)
        
              select distinct jd.reason_for_call, jd.conclusion, jd.alternative, ui.name as agentName, ui.customerPhoneNumber, ui.transcription_id, ui.call_recording_id, (jd.ct*100/ts.ct) percent, pcr.url as call_recording_url  from total_count jd
              inner join users_information ui on ui.transcription_id = jd.transcription_id
              inner join total_sum ts on ts.transcription_id = jd.transcription_id	 
              inner join provider_call_recordings pcr on pcr.id = ui.call_recording_id
              where jd.participant_role = 'CUSTOMER' and jd.sentiment = 'NEGATIVE' and ui.row_number = 1 
              ORDER BY percent desc


              -- GROUP BY jd.workspace_id, jd.sentiment, ts.ct , jd.participant_role, jd.reason_for_call, jd.alternative, jd.conclusion, ui.name, ui.customerPhoneNumber
        $$;

alter function aidashboard_summary_conclusion_negative_sentiments(integer, date, date) owner to postgres;

