create function aidashboard_member_performance(workspaceid integer, from_date date, to_date date, sentiment_type character varying, limit_count integer, offset_count integer)
    returns TABLE("userName" character varying, "totalCallCount" integer, "transcribeCallCount" character varying, "transcribeSpecificSentimentCount" character varying, percentage real, "userWorkspaceId" integer)
    language sql
as
$$
    
      with  jsonb_details as (
        select count(tti.id) total_count, tti.workspace_id, tti.sentiment, tti.agent_id, uw.user_id from transliterate_transcription_information tti 
				inner join user_workspaces uw on tti.agent_id = uw.id and uw.status = 'accepted' where tti.created_at::date between from_date and to_date  and tti.workspace_id = workspaceid and tti.job_status = 'COMPLETED' GROUP BY tti.workspace_id, tti.sentiment, tti.agent_id, uw.user_id 
         ),
				 jsonb_sum as (
				 select agent_id, sum(total_count) total_count from jsonb_details GROUP BY agent_id
				 ),
   jsonb_percent as (
        select jd.sentiment, jd.total_count, round((jd.total_count*100)/(select js.total_count from jsonb_sum js where js.agent_id = jd.agent_id),2) percent, agent_id, user_id   from jsonb_details jd GROUP BY jd.sentiment,jd.agent_id, jd.user_id, jd.total_count
				)
				
        select asa.name, asa.call_count, asa.transcribedCallCount, sum(asa.transcribedSpecificCount) transcribedSpecificCount, sum(asa.positive_percent)positive_percent, asa.user_workspace_id from 
				(select uu.name, count(mc."id") call_count, (js.total_count) as transcribedCallCount, jp.total_count as transcribedSpecificCount, jp.percent as positive_percent,jp.agent_id as user_workspace_id from jsonb_percent jp 
         inner join message_conversations mc on mc.agent_id = jp.agent_id and mc.conversation_type = 'conference' and mc.conversation_status = 'completed' and mc.created_at::date between from_date and to_date and mc.workspace_id = workspaceid
         inner join users uu on uu.id = jp.user_id
				 inner join jsonb_sum js on js.agent_id = jp.agent_id
				 where case when sentiment_type = 'NEGATIVE' then jp.sentiment::varchar = 'NEGATIVE' else jp.sentiment::varchar in ('POSITIVE', 'NEUTRAL') end
				 GROUP BY uu.name, jp.total_count, js.total_count, jp.agent_id, jp.percent
          ORDER BY positive_percent desc
          LIMIT limit_count OFFSET offset_count
				 ) asa GROUP BY asa.name, asa.call_count, asa.transcribedCallCount, asa.user_workspace_id  ;
				 
       $$;

alter function aidashboard_member_performance(integer, date, date, varchar, integer, integer) owner to postgres;

