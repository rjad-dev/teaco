create function activity_timeline_on_chat_sessions() returns trigger
    language plpgsql
as
$$
    DECLARE
      type varchar(50);
      attributes jsonb;
      assignee_details jsonb;
    BEGIN
        SELECT 
            jsonb_build_object(
                'id', a.id,
                'name', a.name,
                'email', a.email,
                'phone_number', a.phone_number
            ) INTO assignee_details
        FROM authenticator_users a
        WHERE a.id = NEW.assignee_id;

        type := 'ASSIGNED';
        attributes := to_jsonb(NEW) || jsonb_build_object('assignee', assignee_details);

        INSERT INTO providers_activity_timelines 
          (contact_id, activity_by_id, entity, entity_type, type, attributes, created_at, updated_at)
          VALUES
          (NEW.contact_id, NEW.updated_by_id, NEW.id, TG_ARGV[0], type::public.enum_providers_activity_timelines_type, attributes, NOW(), NOW());
        RETURN NEW;
    END;
    $$;

alter function activity_timeline_on_chat_sessions() owner to postgres;

