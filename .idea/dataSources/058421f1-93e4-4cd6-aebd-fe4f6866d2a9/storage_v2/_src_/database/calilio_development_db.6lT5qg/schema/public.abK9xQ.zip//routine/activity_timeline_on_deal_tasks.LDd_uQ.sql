create function activity_timeline_on_deal_tasks() returns trigger
    language plpgsql
as
$$
    BEGIN
        IF TG_OP='INSERT' THEN
          UPDATE providers_activity_timelines a
          SET deal_id = new.deal_id
          WHERE a.entity = new.task_id;
        END IF;
        RETURN NEW;
    END;
    $$;

alter function activity_timeline_on_deal_tasks() owner to postgres;

