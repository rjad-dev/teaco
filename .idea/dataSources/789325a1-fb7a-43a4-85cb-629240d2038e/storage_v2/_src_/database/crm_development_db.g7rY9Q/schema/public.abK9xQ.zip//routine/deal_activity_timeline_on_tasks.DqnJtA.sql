create function deal_activity_timeline_on_tasks() returns trigger
    language plpgsql
as
$$
        DECLARE
            type VARCHAR(50);
            attributes JSONB;
            created_by_details JSONB;
            updated_by_details JSONB;
            dealIdNo INT;
            task_details JSONB;
        BEGIN
            IF NEW.contact_id IS NOT NULL THEN
                RETURN NEW;
            END IF;
            IF TG_OP = 'UPDATE' THEN
                IF NEW.deleted_at IS NOT NULL THEN
                    type := 'DELETED';
                ELSE
                    type:= 'UPDATED';
                END IF;
                
                -- Fetching the deal_id associated with the task
                SELECT deal_id INTO dealIdNo
                FROM providers_deal_tasks d
                WHERE d.task_id = NEW.id;

                -- Aggregating attributes from the updated task
                SELECT jsonb_object_agg(key, value)
                INTO attributes
                FROM jsonb_each(to_jsonb(NEW));
                
                -- Fetching details of the user who updated the task
                SELECT json_build_object(
                        'id', u.id,
                        'name', u.name,
                        'email', u.email
                    ) INTO updated_by_details
                    FROM authenticator_users u
                    WHERE u.id = NEW.updated_by_id;
                    
                -- Adding updated_by_details to attributes
                attributes := attributes || jsonb_build_object('updated_by', updated_by_details);
                IF NEW.title <> OLD.title THEN
                    attributes := attributes || jsonb_build_object(
                        'old_title', OLD.title,
                        'new_title', NEW.title
                    );
                END IF;
            ELSE
                -- For newly added tasks
                type := 'ADDED';
                
                -- Fetching details of the user who created the task
                SELECT json_build_object(
                    'id', u.id,
                    'name', u.name,
                    'email', u.email
                ) INTO created_by_details
                FROM authenticator_users u
                WHERE id = NEW.created_by_id;
                
                -- Fetching details of the user who updated the task (for consistency)
                SELECT json_build_object(
                    'id', u.id,
                    'name', u.name,
                    'email', u.email
                ) INTO updated_by_details
                FROM authenticator_users u
                WHERE id = NEW.updated_by_id;
                
                -- Merging task details with user details
                attributes := to_jsonb(NEW) || jsonb_build_object(
                    'created_by', created_by_details,
                    'updated_by', updated_by_details
                );
            END IF;
            
            -- Inserting the activity record into providers_activity_timelines table
            INSERT INTO providers_activity_timelines (
                deal_id,
                activity_by_id,
                entity,
                entity_type,
                type,
                attributes,
                created_at,
                updated_at
            )
            VALUES (
                dealIdNo,
                NEW.updated_by_id,
                NEW.id,
                TG_ARGV[0],
                type::public.enum_providers_activity_timelines_type,
                attributes,
                NOW(),
                NOW()
            );
            
            RETURN NEW;
        END;
        $$;

alter function deal_activity_timeline_on_tasks() owner to postgres;

