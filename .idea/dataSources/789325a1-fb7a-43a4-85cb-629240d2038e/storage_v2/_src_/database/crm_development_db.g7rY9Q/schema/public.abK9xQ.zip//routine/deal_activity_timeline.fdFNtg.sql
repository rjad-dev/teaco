create function deal_activity_timeline() returns trigger
    language plpgsql
as
$$
      DECLARE
        type VARCHAR(50);
        attributes JSONB;
        created_by_details JSONB;
        updated_by_details JSONB;
        fromMilestone VARCHAR(50);
        toMilestone VARCHAR(50);
        fromPipeline VARCHAR(50);
        toPipeline VARCHAR(50);
        milestoneName VARCHAR(50);
        pipelineName VARCHAR(50);
        dealAmount INT;
      BEGIN
        IF TG_OP='UPDATE' THEN
          IF NEW.deleted_at IS NOT NULL THEN
            type := 'DELETED';
          ELSE
            type := 'UPDATED';
          END IF;

          -- Fetch updated_by_details first
          SELECT json_build_object(
            'id', u.id,
            'name', u.name,
            'email', u.email
          ) INTO updated_by_details
          FROM authenticator_users u
          WHERE u.id = NEW.updated_by_id;

          attributes = jsonb_build_object('updated_by', updated_by_details);

          IF NEW.milestone_id <> OLD.milestone_id THEN
            SELECT fm.name INTO fromMilestone FROM providers_milestones fm WHERE fm.id = OLD.milestone_id;
            SELECT tm.name INTO toMilestone FROM providers_milestones tm WHERE tm.id = NEW.milestone_id;
            attributes = attributes || jsonb_build_object(
              'shift', 'true',
              'fromMilestone', fromMilestone,
              'toMilestone', toMilestone
            );
          END IF;

          IF NEW.pipeline_id <> OLD.pipeline_id THEN
            SELECT fm.name INTO fromPipeline FROM providers_pipelines fm WHERE fm.id = OLD.pipeline_id;
            SELECT tm.name INTO toPipeline FROM providers_pipelines tm WHERE tm.id = NEW.pipeline_id;
            attributes = attributes || jsonb_build_object(
              'shift', 'true',
              'fromPipeline', fromPipeline,
              'toPipeline', toPipeline
            );
          END IF;

          IF NEW.amount <> OLD.amount THEN
            SELECT m.name INTO toMilestone FROM providers_milestones m WHERE m.id = NEW.milestone_id;
            SELECT am.amount INTO dealAmount FROM providers_deals am WHERE am.id = NEW.id;
            attributes = attributes || jsonb_build_object(
              'dealAmount', dealAmount,
              'toMilestone', toMilestone
            );
          END IF;

          IF NEW.name <> OLD.name THEN
            attributes = attributes || jsonb_build_object(
              'oldname', OLD.name,
              'newname', NEW.name
            );
          END IF;
      
        ELSE
          type := 'ADDED';
          SELECT json_build_object(
            'id', u.id,
            'name', u.name,
            'email', u.email
          ) INTO created_by_details
          FROM authenticator_users u
          WHERE id = NEW.created_by_id;

          SELECT json_build_object(
            'id', u.id,
            'name', u.name,
            'email', u.email
          ) INTO updated_by_details
          FROM authenticator_users u
          WHERE id = NEW.updated_by_id;

          SELECT fm.name INTO milestoneName
          FROM providers_milestones fm
          WHERE fm.id = NEW.milestone_id;

          -- Merging task details with user details
          attributes := to_jsonb(NEW) || jsonb_build_object(
            'created_by', created_by_details,
            'updated_by', updated_by_details,
            'milestoneName', milestoneName
          );
        END IF;

        INSERT INTO providers_activity_timelines (
          deal_id,
          activity_by_id,
          entity,
          entity_type,
          type,
          attributes,
          created_at,
          updated_at
        )
        VALUES (
          NEW.id,
          NEW.updated_by_id,
          NEW.id,
          TG_ARGV[0],
          type::public.enum_providers_activity_timelines_type,
          COALESCE(attributes, '{}'::JSONB),
          NOW(),
          NOW()
        );

        RETURN NEW;
      END;
      $$;

alter function deal_activity_timeline() owner to postgres;

