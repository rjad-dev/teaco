create function function_bulk_create_contacts() returns trigger
    language plpgsql
as
$$
    DECLARE
        contact_exists jsonb;
    BEGIN
        IF NEW.entity = 'providers_contacts' THEN
            SELECT INTO contact_exists * FROM providers_contacts
            WHERE email = NEW.attributes->>'email' AND owner_id = NEW.owner_id AND deleted_at IS NULL;
    
            IF contact_exists IS NOT NULL THEN
                UPDATE providers_contacts
                SET
                  name = NEW.attributes->>'name',
                  address = NEW.attributes->>'address',
                  company = NEW.attributes->>'company',
                  company_domain = NEW.attributes->>'companyDomain',
                  contact_number = NEW.attributes->>'contactNumber',
                  updated_by_id = (NEW.attributes->>'updatedById')::int
                WHERE email = NEW.attributes->>'email' AND owner_id = NEW.owner_id;

                DELETE FROM providers_temp_tables
                WHERE id = NEW.id;
                RETURN NEW;
            ELSE
                INSERT INTO providers_contacts (
                    owner_id, name, email, address, company, company_domain, contact_number,
                    status, source, profile_picture_id, created_by_id, updated_by_id, created_at, updated_at
                ) VALUES (
                    NEW.owner_id, NEW.attributes->>'name', NEW.attributes->>'email', NEW.attributes->>'address', NEW.attributes->>'company', NEW.attributes->>'companyDomain', NEW.attributes->>'contactNumber',
                    (NEW.attributes->>'status')::public.enum_providers_contacts_status, 'MANUALLY', (NEW.attributes->>'profilePictureId')::int, (NEW.attributes->>'createdById')::int, (NEW.attributes->>'updatedById')::int, NEW.created_at, NEW.updated_at
                  );
                DELETE FROM providers_temp_tables
                WHERE id = NEW.id;
                RETURN NEW;
            END IF;
        ELSE 
            RETURN NULL;
        END IF;
    END;
    $$;

alter function function_bulk_create_contacts() owner to postgres;

